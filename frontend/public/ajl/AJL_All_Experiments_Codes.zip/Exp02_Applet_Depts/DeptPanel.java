import java.awt.*;
import java.awt.event.*;

public class DeptPanel extends Panel implements ItemListener {
    List list;
    TextField tf;

    public void init() {
        list = new List(5);
        list.add("Computer Science");
        list.add("Electronics");
        list.add("Mechanical");
        list.add("Civil");
        list.add("Electrical");

        tf = new TextField(25);

        add(new Label("Select Department:"));
        add(list);
        add(new Label("You selected:"));
        add(tf);

        list.addItemListener(this);
    }

    public void itemStateChanged(ItemEvent e) {
        tf.setText(list.getSelectedItem());
    }

    public static void main(String[] args) {
        Frame f = new Frame("Departments");
        DeptPanel p = new DeptPanel();
        p.init();
        f.add(p);
        f.setSize(350, 250);
        f.setVisible(true);
        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}