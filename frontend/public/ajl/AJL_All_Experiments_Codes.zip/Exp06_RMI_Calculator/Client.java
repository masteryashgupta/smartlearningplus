import java.rmi.registry.*;
import java.util.Scanner;

public class Client {
    public static void main(String args[]) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            Calculator obj = (Calculator) registry.lookup("CalculatorService");

            Scanner sc = new Scanner(System.in);
            System.out.print("Enter First Number : ");
            double a = sc.nextDouble();
            System.out.print("Enter Operator (+,-,*,/) : ");
            char op = sc.next().charAt(0);
            System.out.print("Enter Second Number : ");
            double b = sc.nextDouble();

            double result = obj.calculate(a, b, op);
            System.out.println("Result = " + result);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}