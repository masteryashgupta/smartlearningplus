CGML – Computer Graphics & Multimedia Lab (5CS4-21)
All Experiments C Source Codes & Turbo C++ Setup Guide
======================================================

Total Experiments: 6
Programming Language: C (Turbo C++ / Borland Graphics Interface - BGI)

Included Files in this Zip:
---------------------------
  README.txt                    – This guide and experiment summary
  TURBO_C_SETUP.txt             – Step-by-step Turbo C++ setup instructions
  cgm_exp1.c to cgm_exp6.c      – Direct C source code files (ready to drop into C:\TURBOC3\BIN)

Organized Experiment Folders:
----------------------------
  Exp01_Basic_Graphics/
    cgm_exp1.c                  – Draw line, circle, ellipse, rectangle, heart, smiley face
  Exp02_Plot_Pixel_Colours/
    cgm_exp2.c                  – Plot pixel in different colours (1 to 15) using putpixel
  Exp03_DDA_Line_Drawing/
    cgm_exp3.c                  – Digital Differential Analyzer (DDA) line algorithm
  Exp04_Bresenham_Line_Drawing/
    cgm_exp4.c                  – Bresenham's line drawing algorithm (all slopes & directions)
  Exp05_Midpoint_Circle_Generation/
    cgm_exp5.c                  – Midpoint circle algorithm with 8-way symmetry
  Exp06_Midpoint_Ellipse_Generation/
    cgm_exp6.c                  – Midpoint ellipse algorithm with Region 1 & Region 2

HTML Manuals:
-------------
  HTML_Manuals/all.html         – All-in-one lab manual with tabbed UI, theory, and viva Q&A
  HTML_Manuals/cgm_exp1.html to cgm_exp6.html – Standalone experiment manuals

------------------------------------------------------
TURBO C++ ONE-TIME SETUP GUIDE
------------------------------------------------------
1. Check Linker Settings (MANDATORY):
   In Turbo C++, go to:
     Options -> Linker -> Libraries
   Ensure "Graphics library" has an [X] mark.
   If not enabled, linking will fail with: "Undefined symbol _initgraph".

2. Check BGI Directory Path:
   In each .c file, initgraph() specifies the path to BGI drivers:
     initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
   Make sure the path matches your Turbo C++ installation folder containing EGAVGA.BGI.
   (Note: in C strings, backslashes must be doubled: "C:\\TURBOC3\\BGI").

3. File Extension:
   Always save the files with a .C extension (e.g., EXP1.C) so Turbo C++ compiles them as standard C.

4. Compiling & Running:
   - Press Ctrl + F9 to compile and run.
   - Press Alt + F5 to view the user screen / output if the window closes.
   - Press any key when the graphics window is open to exit back to the editor.
