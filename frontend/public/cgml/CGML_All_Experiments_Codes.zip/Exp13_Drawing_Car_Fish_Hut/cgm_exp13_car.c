#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<dos.h>
#include<graphics.h>

void car(int x, int y, int color)
{
    int wheel;
    if(color == BLACK)
        wheel = BLACK;
    else
        wheel = WHITE;

    setcolor(color);
    rectangle(x, y - 20, x + 100, y);              /* lower body */
    line(x + 20, y - 20, x + 35, y - 45);          /* roof, left slope */
    line(x + 35, y - 45, x + 70, y - 45);          /* roof, top */
    line(x + 70, y - 45, x + 85, y - 20);          /* roof, right slope */
    line(x + 52, y - 45, x + 52, y - 20);          /* window divider */

    setcolor(wheel);
    circle(x + 25, y + 5, 10);                     /* wheels */
    circle(x + 75, y + 5, 10);
    circle(x + 25, y + 5, 3);
    circle(x + 75, y + 5, 3);
}

void main()
{
    int gd = DETECT, gm, err;
    int x, y = 300;

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    for(x = 0; x < 530 && !kbhit(); x += 4)
    {
        setcolor(WHITE);
        line(0, y + 15, 639, y + 15);              /* road */
        car(x, y, RED);
        delay(30);
        car(x, y, BLACK);
    }

    setcolor(WHITE);
    line(0, y + 15, 639, y + 15);
    car(x, y, RED);

    getch();
    closegraph();
}