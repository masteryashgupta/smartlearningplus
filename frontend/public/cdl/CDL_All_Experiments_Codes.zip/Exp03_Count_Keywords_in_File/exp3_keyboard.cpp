#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<ctype.h>

void main()
{
    char keyword[32][10] = {"auto","double","int","struct","break","else","long",
                            "switch","case","enum","register","typedef","char",
                            "extern","return","union","const","float","short",
                            "unsigned","continue","for","signed","void","default",
                            "goto","sizeof","volatile","do","if","static","while"};
    char text[200], word[20];
    int i, j = 0, k, count = 0;

    clrscr();
    printf("Enter a line of text: ");
    gets(text);

    for(i = 0; ; i++)
    {
        if(isalpha(text[i]))
        {
            word[j++] = text[i];
        }
        else
        {
            if(j > 0)
            {
                word[j] = '\0';
                for(k = 0; k < 32; k++)
                {
                    if(strcmp(word, keyword[k]) == 0)
                    {
                        count++;
                        break;
                    }
                }
                j = 0;
            }
            if(text[i] == '\0')
                break;
        }
    }

    printf("Total keywords = %d", count);
    getch();
}