#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

void main()
{
    char fname[30];
    int c, count = 0;
    FILE *fp;

    clrscr();
    printf("Enter file name: ");
    gets(fname);

    fp = fopen(fname, "r");
    if(fp == NULL)
    {
        printf("File not found");
        getch();
        exit(0);
    }

    while((c = fgetc(fp)) != EOF)
    {
        if(c == '+' || c == '-' || c == '*' || c == '/')
            count++;
    }

    fclose(fp);
    printf("Number of operators in the file = %d", count);
    getch();
}