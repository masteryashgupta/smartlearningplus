#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<graphics.h>

void main()
{
    int gd = DETECT, gm, err;

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    setcolor(WHITE);

    /* outlines */
    rectangle(200, 250, 400, 370);              /* wall */
    line(190, 250, 300, 170);                   /* roof */
    line(300, 170, 410, 250);
    line(410, 250, 190, 250);
    rectangle(280, 300, 320, 370);              /* door */
    rectangle(220, 280, 260, 320);              /* window */
    circle(520, 100, 30);                       /* sun */
    line(0, 370, 639, 370);                     /* ground */

    /* colours */
    setfillstyle(SOLID_FILL, RED);
    floodfill(300, 220, WHITE);                 /* roof */
    setfillstyle(SOLID_FILL, BROWN);
    floodfill(230, 350, WHITE);                 /* wall */
    setfillstyle(SOLID_FILL, LIGHTBLUE);
    floodfill(240, 300, WHITE);                 /* window */
    setfillstyle(SOLID_FILL, DARKGRAY);
    floodfill(300, 340, WHITE);                 /* door */
    setfillstyle(SOLID_FILL, YELLOW);
    floodfill(520, 100, WHITE);                 /* sun */
    setfillstyle(SOLID_FILL, GREEN);
    floodfill(100, 420, WHITE);                 /* grass */

    /* window frame */
    line(240, 280, 240, 320);
    line(220, 300, 260, 300);

    outtextxy(260, 60, "My Hut");

    getch();
    closegraph();
}