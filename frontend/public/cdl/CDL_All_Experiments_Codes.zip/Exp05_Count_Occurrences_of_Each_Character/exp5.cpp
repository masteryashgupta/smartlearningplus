#include<stdio.h>
#include<conio.h>
#include<ctype.h>

void main()
{
    char string[100];
    int count[26] = {0};
    int c = 0;

    clrscr();
    printf("Enter a string\n");
    gets(string);

    while(string[c] != '\0')
    {
        if(isalpha(string[c]))
        {
            count[tolower(string[c]) - 'a']++;
        }
        c++;
    }

    for(c = 0; c < 26; c++)
    {
        if(count[c] > 0)
            printf("%c occurs %d times in the string.\n", c + 'a', count[c]);
    }
    getch();
}