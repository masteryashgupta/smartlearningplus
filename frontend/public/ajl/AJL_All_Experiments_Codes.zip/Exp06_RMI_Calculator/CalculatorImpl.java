import java.rmi.*;
import java.rmi.server.*;

public class CalculatorImpl extends UnicastRemoteObject implements Calculator {

    public CalculatorImpl() throws RemoteException {
        super();
    }

    public double calculate(double a, double b, char op) throws RemoteException {
        switch (op) {
            case '+':
                return a + b;
            case '-':
                return a - b;
            case '*':
                return a * b;
            case '/':
                if (b != 0)
                    return a / b;
                else {
                    System.out.println("Division by zero not possible.");
                    return 0;
                }
            default:
                System.out.println("Invalid Operator");
                return 0;
        }
    }
}