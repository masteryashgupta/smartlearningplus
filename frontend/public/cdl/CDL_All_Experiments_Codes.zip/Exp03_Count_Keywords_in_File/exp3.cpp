#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>

void main()
{
    char keyword[32][10] = {"auto","double","int","struct","break","else","long",
                            "switch","case","enum","register","typedef","char",
                            "extern","return","union","const","float","short",
                            "unsigned","continue","for","signed","void","default",
                            "goto","sizeof","volatile","do","if","static","while"};
    char fname[30], word[20];
    int c, i, j = 0, count = 0;
    FILE *fp;

    clrscr();
    printf("Enter file name: ");
    gets(fname);

    fp = fopen(fname, "r");
    if(fp == NULL)
    {
        printf("File not found");
        getch();
        exit(0);
    }

    while(1)
    {
        c = fgetc(fp);

        if(isalpha(c))
        {
            word[j++] = c;
        }
        else
        {
            if(j > 0)
            {
                word[j] = '\0';
                for(i = 0; i < 32; i++)
                {
                    if(strcmp(word, keyword[i]) == 0)
                    {
                        count++;
                        break;
                    }
                }
                j = 0;
            }
            if(c == EOF)
                break;
        }
    }

    fclose(fp);
    printf("Total keywords in file = %d", count);
    getch();
}