#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<math.h>
#include<dos.h>
#include<graphics.h>

void heli(int x, int y, int color, int frame)
{
    setcolor(color);
    ellipse(x, y, 0, 360, 40, 20);            /* body */
    arc(x - 15, y, 20, 160, 15);              /* cockpit window */
    line(x + 35, y - 8, x + 100, y - 12);     /* tail, upper edge */
    line(x + 38, y + 2, x + 100, y - 6);      /* tail, lower edge */
    line(x + 100, y - 12, x + 100, y - 6);    /* tail end */
    line(x, y - 20, x, y - 30);               /* mast */
    line(x - 35, y + 30, x + 35, y + 30);     /* skid */
    line(x - 15, y + 19, x - 20, y + 30);     /* skid strut */
    line(x + 15, y + 19, x + 20, y + 30);     /* skid strut */

    if(frame % 2 == 0)
    {
        line(x - 60, y - 30, x + 60, y - 30);         /* main rotor */
        line(x + 100, y - 24, x + 100, y + 6);        /* tail rotor */
    }
    else
    {
        line(x - 45, y - 33, x + 45, y - 27);
        line(x + 94, y - 22, x + 106, y + 4);
    }
}

void main()
{
    int gd = DETECT, gm, err;
    int x, y, frame = 0;

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    for(x = 20; x < 500 && !kbhit(); x += 4)
    {
        y = 150 + (int)(20 * sin(x / 25.0));
        heli(x, y, WHITE, frame);
        delay(40);
        heli(x, y, BLACK, frame);
        frame++;
    }

    y = 150 + (int)(20 * sin(x / 25.0));
    heli(x, y, WHITE, frame);

    getch();
    closegraph();
}