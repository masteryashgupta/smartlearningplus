#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<graphics.h>

extern unsigned _stklen = 40000U;

void boundaryfill4(int x, int y, int fillcol, int bordercol)
{
    int cur;
    cur = getpixel(x, y);
    if(cur != bordercol && cur != fillcol)
    {
        putpixel(x, y, fillcol);
        boundaryfill4(x + 1, y, fillcol, bordercol);
        boundaryfill4(x - 1, y, fillcol, bordercol);
        boundaryfill4(x, y + 1, fillcol, bordercol);
        boundaryfill4(x, y - 1, fillcol, bordercol);
    }
}

void main()
{
    int gd = DETECT, gm, err;
    int col;

    clrscr();
    printf("Enter fill colour (1 to 14): ");
    scanf("%d", &col);
    if(col < 1 || col > 14)
    {
        printf("Colour must be between 1 and 14");
        getch();
        exit(0);
    }

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    setcolor(WHITE);
    rectangle(100, 100, 160, 140);

    boundaryfill4(130, 120, col, WHITE);

    getch();
    closegraph();
}