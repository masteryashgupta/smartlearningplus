CGML – Computer Graphics & Multimedia Lab (5CS4-21)
All Experiments C Source Codes & Turbo C++ Setup Guide
======================================================

Total Experiments: 15
Total Code Files: 18
Programming Language: C (Turbo C++ / Borland Graphics Interface - BGI)

Included Files in this Zip:
---------------------------
  README.txt                    – This guide and experiment summary
  TURBO_C_SETUP.txt             – Step-by-step Turbo C++ setup instructions
  All 18 .c source code files   – Ready to drop directly into C:\TURBOC3\BIN

Organized Experiment Folders:
----------------------------
  Exp01_Basic_Graphics/
    cgm_exp1.c                  – Draw line, circle, ellipse, rectangle, heart, smiley face
  Exp02_Plot_Pixel_Colours/
    cgm_exp2.c                  – Plot pixel in different colours (1 to 15) using putpixel
  Exp03_DDA_Line_Drawing/
    cgm_exp3.c                  – Digital Differential Analyzer (DDA) line algorithm
  Exp04_Bresenham_Line_Drawing/
    cgm_exp4.c                  – Bresenham's line drawing algorithm (all slopes & directions)
  Exp05_Midpoint_Circle_Generation/
    cgm_exp5.c                  – Midpoint circle algorithm with 8-way symmetry
  Exp06_Midpoint_Ellipse_Generation/
    cgm_exp6.c                  – Midpoint ellipse algorithm with Region 1 & Region 2
  Exp07_2D_Transformations/
    cgm_exp7.c                  – 2D transformations (translation, scaling, rotation, shearing, reflection)
  Exp08_Flood_Fill_Algorithm/
    cgm_exp8.c                  – Recursive 4-connected flood fill algorithm
  Exp09_Boundary_Fill_Algorithm/
    cgm_exp9.c                  – Recursive 4-connected boundary fill algorithm
  Exp10_Cohen_Sutherland_Line_Clipping/
    cgm_exp10.c                 – Cohen-Sutherland line clipping algorithm with region outcodes
  Exp11_3D_Transformations/
    cgm_exp11.c                 – 3D transformations (translation, scaling, rotation of 3D box)
  Exp12_Animation_Helicopter_Fan/
    cgm_exp12_helicopter.c      – Moving helicopter animation with rotating rotor
    cgm_exp12_fan.c             – Rotating fan animation with 3 blades
  Exp13_Drawing_Car_Fish_Hut/
    cgm_exp13_car.c             – Moving car animation on road
    cgm_exp13_fish.c            – Oscillating sinusoidal swimming fish animation
    cgm_exp13_hut.c             – Complete landscape drawing of a hut
  Exp14_Scanline_Polygon_Fill/
    cgm_exp14.c                 – Scan-line polygon fill algorithm with intersection sorting
  Exp15_Bezier_Curve/
    cgm_exp15.c                 – Cubic Bezier curve using 4 control points & Bernstein polynomials

HTML Manuals:
-------------
  HTML_Manuals/all.html         – All-in-one lab manual with tabbed UI, theory, and viva Q&A
  HTML_Manuals/cgm_exp1.html to cgm_exp15.html – Standalone experiment manuals

------------------------------------------------------
TURBO C++ ONE-TIME SETUP GUIDE
------------------------------------------------------
1. Check Linker Settings (MANDATORY):
   In Turbo C++, go to:
     Options -> Linker -> Libraries
   Ensure "Graphics library" has an [X] mark.
   If not enabled, linking will fail with: "Undefined symbol _initgraph".

2. Check BGI Directory Path:
   In each .c file, initgraph() specifies the path to BGI drivers:
     initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
   Make sure the path matches your Turbo C++ installation folder containing EGAVGA.BGI.
   (Note: in C strings, backslashes must be doubled: "C:\\TURBOC3\\BGI").

3. File Extension:
   Always save the files with a .C extension (e.g., EXP1.C) so Turbo C++ compiles them as standard C.

4. Compiling & Running:
   - Press Ctrl + F9 to compile and run.
   - Press Alt + F5 to view the user screen / output if the window closes.
   - Press any key when the graphics window is open to exit back to the editor.
