#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<graphics.h>

void main()
{
    int gd = DETECT, gm, err;
    int x, y, r;

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    /* 1. Line: yellow, dashed, thick */
    setcolor(YELLOW);
    setlinestyle(DASHED_LINE, 0, THICK_WIDTH);
    line(30, 150, 190, 70);
    outtextxy(80, 190, "Line");

    /* back to a normal solid line for the other shapes */
    setlinestyle(SOLID_LINE, 0, NORM_WIDTH);

    /* 2. Circle: white outline, red fill */
    setcolor(WHITE);
    circle(320, 110, 50);
    setfillstyle(SOLID_FILL, RED);
    floodfill(320, 110, WHITE);
    outtextxy(295, 190, "Circle");

    /* 3. Ellipse: green */
    setcolor(GREEN);
    ellipse(530, 110, 0, 360, 70, 40);
    outtextxy(505, 190, "Ellipse");

    /* 4. Rectangle: cyan */
    setcolor(CYAN);
    rectangle(60, 260, 160, 340);
    outtextxy(70, 400, "Rectangle");

    /* 5. Smiley face: yellow head, eyes, smile */
    setcolor(YELLOW);
    circle(320, 300, 45);
    circle(305, 288, 5);
    circle(335, 288, 5);
    arc(320, 300, 200, 340, 25);
    outtextxy(280, 400, "Smiley face");

    /* 6. Heart: two arcs and two lines */
    setcolor(RED);
    x = 530; y = 270; r = 25;
    arc(x - r, y, 0, 180, r);
    arc(x + r, y, 0, 180, r);
    line(x - 2 * r, y, x, y + 3 * r);
    line(x + 2 * r, y, x, y + 3 * r);
    setfillstyle(SOLID_FILL, RED);
    floodfill(x, y + 30, RED);
    outtextxy(505, 400, "Heart");

    getch();
    closegraph();
}