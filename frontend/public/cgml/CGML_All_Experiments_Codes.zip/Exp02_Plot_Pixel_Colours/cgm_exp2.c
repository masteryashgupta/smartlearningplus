#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<graphics.h>

void main()
{
    int gd = DETECT, gm, err;
    int c, x, y;
    char msg[40];

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    /* the pixels from the manual */
    putpixel(85, 35, GREEN);
    putpixel(30, 40, RED);
    putpixel(115, 50, YELLOW);
    putpixel(135, 50, CYAN);
    putpixel(45, 60, BLUE);
    putpixel(20, 100, WHITE);
    putpixel(200, 100, LIGHTBLUE);
    putpixel(150, 100, LIGHTGREEN);
    putpixel(200, 50, YELLOW);
    putpixel(120, 70, RED);

    /* a strip of pixels in every colour from 1 to 15 */
    for(c = 1; c <= 15; c++)
    {
        for(x = 0; x < 30; x++)
        {
            for(y = 0; y < 10; y++)
            {
                putpixel(100 + c * 30 + x, 200 + y, c);
            }
        }
    }

    outtextxy(100, 180, "Pixels in colours 1 to 15");

    /* read a pixel back with getpixel */
    c = getpixel(85, 35);
    sprintf(msg, "Colour of pixel (85,35) = %d", c);
    outtextxy(100, 300, msg);

    getch();
    closegraph();
}