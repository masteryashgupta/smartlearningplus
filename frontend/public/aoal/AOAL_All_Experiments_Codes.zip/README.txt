AOAL – Analysis of Algorithms Lab (5CS4-23 / 5CS4-24)
All Experiments C Source Codes & Compilation Guide
===================================================

Total Experiments: 14
Total Code Files: 14
Programming Language: C (C99 / GCC)

Contents in this Archive:
-------------------------
  README.txt                    – This guide and experiment overview
  COMPILATION_GUIDE.txt         – Step-by-step GCC compilation instructions
  all.html                      – Interactive all-in-one lab manual (Theory, Code, Output, Viva Q&A)

Organized Experiment Folders:
----------------------------
  Exp01_Quick_Sort/
    aoa_exp1.c                  – Quick Sort with random numbers and execution timer
  Exp02_Merge_Sort/
    aoa_exp2.c                  – Merge Sort with random numbers and execution timer
  Exp03_Bubble_Sort/
    aoa_exp3.c                  – Bubble Sort algorithm and time measurement
  Exp04_Linear_Search/
    aoa_exp4.c                  – Linear Search algorithm and time measurement
  Exp05_Binary_Search/
    aoa_exp5.c                  – Binary Search (recursive and iterative)
  Exp06_Strassen_Matrix_Multiplication/
    aoa_exp6.c                  – Strassen's matrix multiplication (2x2 submatrices)
  Exp07_Fractional_Knapsack_Greedy/
    aoa_exp7.c                  – Fractional Knapsack using Greedy Method (value/weight ratio)
  Exp08_Prims_Minimum_Spanning_Tree/
    aoa_exp8.c                  – Minimum Cost Spanning Tree using Prim's algorithm
  Exp09_Kruskals_Minimum_Spanning_Tree/
    aoa_exp9.c                  – Minimum Cost Spanning Tree using Kruskal's algorithm (Disjoint Set)
  Exp10_01_Knapsack_Dynamic_Programming/
    aoa_exp10.c                 – 0/1 Knapsack problem using Dynamic Programming
  Exp11_Longest_Common_Subsequence/
    aoa_exp11.c                 – Longest Common Subsequence (LCS) using Dynamic Programming
  Exp12_Matrix_Chain_Multiplication/
    aoa_exp12.c                 – Matrix Chain Multiplication (MCM) using Dynamic Programming
  Exp13_N_Queens_Backtracking/
    aoa_exp13.c                 – N-Queens problem using Backtracking
  Exp14_Naive_String_Matching/
    aoa_exp14.c                 – Naive string-matching algorithm

------------------------------------------------------
COMPILATION & RUNNING INSTRUCTIONS
------------------------------------------------------
1. Using GCC (MinGW on Windows, or GCC on Linux/macOS):
   Navigate to the folder containing the .c file and run:
     gcc aoa_exp1.c -o exp1

2. Running the Program:
   - On Windows (Command Prompt / PowerShell):
       exp1
   - On Linux / macOS / Git Bash:
       ./exp1

3. Optimizations (Optional):
   For benchmarking large arrays:
     gcc -O2 aoa_exp1.c -o exp1
