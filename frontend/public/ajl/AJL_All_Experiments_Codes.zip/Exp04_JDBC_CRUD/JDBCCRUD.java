import java.sql.*;

public class JDBCCRUD {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/CollegeDB";
        String user = "root";
        String password = "root123"; // change to your MySQL password

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, password);
            System.out.println("Database Connected Successfully...\n");

            Statement stmt = con.createStatement();

            String createTable = "CREATE TABLE IF NOT EXISTS Student ("
                    + "id INT PRIMARY KEY, "
                    + "name VARCHAR(50), "
                    + "branch VARCHAR(30), "
                    + "marks INT)";
            stmt.executeUpdate(createTable);
            System.out.println("Table Created Successfully.");

            // INSERT
            String insert = "INSERT INTO Student(id,name,branch,marks) VALUES(?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(insert);
            ps.setInt(1, 101);
            ps.setString(2, "Rahul");
            ps.setString(3, "CSE");
            ps.setInt(4, 85);
            ps.executeUpdate();
            System.out.println("Record Inserted Successfully.");

            // UPDATE
            String update = "UPDATE Student SET marks=? WHERE id=?";
            PreparedStatement ps2 = con.prepareStatement(update);
            ps2.setInt(1, 95);
            ps2.setInt(2, 101);
            ps2.executeUpdate();
            System.out.println("Record Updated Successfully.");

            // SELECT
            ResultSet rs = stmt.executeQuery("SELECT * FROM Student");
            System.out.println("\nStudent Records");
            System.out.println("-------------------------------");
            while (rs.next()) {
                System.out.println("ID      : " + rs.getInt("id"));
                System.out.println("Name    : " + rs.getString("name"));
                System.out.println("Branch  : " + rs.getString("branch"));
                System.out.println("Marks   : " + rs.getInt("marks"));
                System.out.println("-------------------------------");
            }

            // DELETE
            String delete = "DELETE FROM Student WHERE id=?";
            PreparedStatement ps3 = con.prepareStatement(delete);
            ps3.setInt(1, 101);
            ps3.executeUpdate();
            System.out.println("Record Deleted Successfully.");

            rs.close();
            ps.close();
            ps2.close();
            ps3.close();
            stmt.close();
            con.close();
            System.out.println("\nConnection Closed.");
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}