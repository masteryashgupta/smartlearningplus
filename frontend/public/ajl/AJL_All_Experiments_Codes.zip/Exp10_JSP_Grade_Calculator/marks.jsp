<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Grade</title>
</head>
<body>
<%
int java = Integer.parseInt(request.getParameter("java"));
int NMA = Integer.parseInt(request.getParameter("NMA"));
int MCAD = Integer.parseInt(request.getParameter("MCAD"));
int PPUD = Integer.parseInt(request.getParameter("PPUD"));
int Project = Integer.parseInt(request.getParameter("pro"));

int total = java + NMA + MCAD + PPUD + Project;
double avg = total / 5.0;

out.println("Total = " + total + "<br>");
out.println("Average = " + avg + "<br>");

if (avg >= 90) {
    out.println("Your grade is A");
} else if (avg >= 80) {
    out.println("Your grade is B");
} else if (avg >= 70) {
    out.println("Your grade is C");
} else if (avg >= 60) {
    out.println("Your grade is D");
} else {
    out.println("Your grade is E");
}
%>
</body>
</html>