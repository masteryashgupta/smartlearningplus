import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("First name is : " + request.getParameter("fname") + "<br>");
        out.println("Last name is : " + request.getParameter("lname") + "<br>");
        out.println("User name is : " + request.getParameter("uname") + "<br>");
        out.println("Email is : " + request.getParameter("email") + "<br>");
        out.println("Address is : " + request.getParameter("add") + "<br>");
        out.println("</body></html>");
    }
}