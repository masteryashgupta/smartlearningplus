<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
String a = request.getParameter("uname");
String b = request.getParameter("pass");
if ("queue".equals(a) && "queue".equals(b)) {
    response.sendRedirect("Welcome.jsp");
} else {
    out.println("Invalid username or password. <a href='Index.html'>Try again</a>");
}
%>