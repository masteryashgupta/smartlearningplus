#include<stdio.h>
#include<conio.h>
#include<ctype.h>
#include<stdlib.h>

void main()
{
    char fname[30];
    int count[26] = {0};
    int c, i;
    FILE *fp;

    clrscr();
    printf("Enter file name: ");
    gets(fname);

    fp = fopen(fname, "r");
    if(fp == NULL)
    {
        printf("File not found");
        getch();
        exit(0);
    }

    while((c = fgetc(fp)) != EOF)
    {
        if(isalpha(c))
        {
            count[tolower(c) - 'a']++;
        }
    }
    fclose(fp);

    for(i = 0; i < 26; i++)
    {
        if(count[i] > 0)
            printf("%c occurs %d times\n", i + 'a', count[i]);
    }
    getch();
}