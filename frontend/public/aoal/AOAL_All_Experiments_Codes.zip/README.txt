AOAL – Analysis of Algorithms Lab (5CS4-23 / 5CS4-24)
All Experiments C Source Codes & Compilation Guide
===================================================

Total Experiments: 6
Programming Language: C (C99 / GCC)

Contents in this Archive:
-------------------------
  README.txt                    – This guide and experiment summary
  COMPILATION_GUIDE.txt         – Step-by-step GCC compilation instructions
  all.html                      – Interactive all-in-one lab manual (Theory, Code, Output, Viva Q&A)

Organized Experiment Folders:
----------------------------
  Exp01_Quicksort/
    exp1_quicksort.c            – Quicksort timing analysis across n = 10,000 to 1,000,000
  Exp02_Parallel_Mergesort/
    exp2_parallel_mergesort.c   – Parallel Merge Sort with OpenMP and speedup calculation
  Exp03_Topological_Warshall/
    exp3_topological_warshall.c – Topological ordering (Kahn's) & Warshall's transitive closure
  Exp05_Dijkstra_Shortest_Path/
    exp5_dijkstra.c             – Dijkstra's single-source shortest paths algorithm with path tracing
  Exp07_BFS_DFS_Traversals/
    exp7_bfs_dfs.c              – BFS reachable nodes in digraph & DFS graph connectivity check
  Exp10_N_Queens_Backtracking/
    exp10_nqueens.c             – N-Queens placement using Backtracking with visual chessboard

------------------------------------------------------
COMPILATION & RUNNING INSTRUCTIONS
------------------------------------------------------
1. Using GCC on Windows (MinGW / MSYS2 / WSL) or Linux / macOS:
     gcc -O2 exp1_quicksort.c -o exp1
     gcc -O2 -fopenmp exp2_parallel_mergesort.c -o exp2
     gcc -O2 exp3_topological_warshall.c -o exp3
     gcc -O2 exp5_dijkstra.c -o exp5
     gcc -O2 exp7_bfs_dfs.c -o exp7
     gcc -O2 exp10_nqueens.c -o exp10

2. Running the Program:
   - On Windows (Command Prompt / PowerShell):
       exp1
   - On Linux / macOS / Git Bash:
       ./exp1
