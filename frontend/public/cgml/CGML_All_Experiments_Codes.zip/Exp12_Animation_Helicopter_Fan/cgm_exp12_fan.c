#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<dos.h>
#include<graphics.h>

void blades(int cx, int cy, int r, int ang, int color)
{
    int i, st, en;
    setcolor(color);
    setfillstyle(SOLID_FILL, color);
    for(i = 0; i < 3; i++)
    {
        st = (ang + i * 120) % 360;
        en = st + 35;
        if(en <= 360)
        {
            pieslice(cx, cy, st, en, r);
        }
        else
        {
            pieslice(cx, cy, st, 360, r);
            pieslice(cx, cy, 0, en - 360, r);
        }
    }
}

void main()
{
    int gd = DETECT, gm, err;
    int ang = 0;

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    setcolor(WHITE);
    circle(320, 240, 130);                  /* guard */

    while(!kbhit())
    {
        blades(320, 240, 120, ang, LIGHTBLUE);
        setcolor(WHITE);
        circle(320, 240, 12);               /* hub */
        delay(60);
        blades(320, 240, 120, ang, BLACK);
        ang = (ang + 15) % 360;
    }

    getch();
    closegraph();
}