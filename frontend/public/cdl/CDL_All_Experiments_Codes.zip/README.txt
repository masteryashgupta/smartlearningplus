CDL – Compiler Design Lab (5CS4-22)
All Experiments Code Files
===================================

Total Experiments: 13
Total Code Files: 26

Folder structure:
  Exp01_Introduction_to_Compiler_Design/
    exp1.txt                  – Theory write-up
  Exp02_Identify_Keyword/
    exp2.cpp                  – Keyword identifier program
  Exp03_Count_Keywords_in_File/
    exp3.cpp                  – Count keywords from file
    exp3_keyboard.cpp         – Count keywords from typed input
  Exp04_Count_Operators_in_String/
    exp4.cpp                  – Count operators in string
    exp4_file.cpp             – Count operators from file
  Exp05_Count_Occurrences_of_Each_Character/
    exp5.cpp                  – Count character occurrences in string
    exp5_file.cpp             – Count character occurrences from file
  Exp06_Symbol_Table_Insert_Delete_Display/
    exp6.cpp                  – Symbol table implementation
  Exp07_LEX_Validate_Mobile_URL_Identifier_Date_Time/
    exp7_mobile.l             – Validate 10-digit mobile number
    exp7_email.l              – Validate email address
    exp7_url.l                – Validate web URL
    exp7_identifier.l         – Validate C identifier
    exp7_date.l               – Validate date (dd/mm/yyyy with leap year)
    exp7_time.l               – Validate time (hh:mm:ss)
  Exp08_LEX_Count_Blank_Spaces_Words_Lines/
    exp8.l                    – Count blanks, words, lines from file
    exp8_keyboard.l           – Count blanks, words, lines from keyboard
  Exp09_LEX_Count_Vowels_Consonants_in_C_File/
    exp9.l                    – Count vowels and consonants in file
    exp9_keyboard.l           – Count vowels and consonants from keyboard
  Exp10_YACC_Recognize_a_n_b_n/
    exp10.l                   – Lexer for a^n b^n
    exp10.y                   – Parser for a^n b^n
  Exp11_YACC_Evaluate_Arithmetic_Expression/
    exp11.l                   – Lexer for arithmetic expressions
    exp11.y                   – Parser & evaluator
  Exp12_YACC_Check_a_n_b_n_c_m_d_m/
    exp12.l                   – Lexer for a^n b^n c^m d^m
    exp12.y                   – Parser for a^n b^n c^m d^m
  Exp13_Find_First_and_Follow_Sets/
    exp13.cpp                 – Find First and Follow sets of a CFG

Running on Windows:
-------------------
1. Install WinFlexBison into C:\flex
2. In C:\flex:
   For LEX programs (Exp 7-9):
     win_flex --wincompat file.l
     gcc -w lex.yy.c -o file
     file

   For YACC + LEX programs (Exp 10-12):
     win_bison -y -d file.y
     win_flex --wincompat file.l
     gcc -w y.tab.c lex.yy.c -o file
     file

   For C++ programs (Exp 2-6, 13):
     g++ file.cpp -o out && out

HTML_Manuals/ folder contains the complete interactive HTML manuals.
