#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<graphics.h>

void plot4(int xc, int yc, int x, int y)
{
    putpixel(xc + x, yc + y, YELLOW);
    putpixel(xc - x, yc + y, YELLOW);
    putpixel(xc + x, yc - y, YELLOW);
    putpixel(xc - x, yc - y, YELLOW);
}

void main()
{
    int gd = DETECT, gm, err;
    int xc, yc, rx, ry, x, y;
    double rx2, ry2, p;

    clrscr();
    printf("Enter centre (xc yc): ");
    scanf("%d%d", &xc, &yc);
    printf("Enter radius along x (rx): ");
    scanf("%d", &rx);
    printf("Enter radius along y (ry): ");
    scanf("%d", &ry);

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    rx2 = (double)rx * rx;
    ry2 = (double)ry * ry;
    x = 0;
    y = ry;

    /* Region 1: slope is less than 1 in magnitude */
    p = ry2 - rx2 * ry + 0.25 * rx2;
    while(ry2 * x <= rx2 * y)
    {
        plot4(xc, yc, x, y);
        x++;
        if(p < 0)
        {
            p = p + 2 * ry2 * x + ry2;
        }
        else
        {
            y--;
            p = p + 2 * ry2 * x - 2 * rx2 * y + ry2;
        }
    }

    /* Region 2: slope is greater than 1 in magnitude */
    p = ry2 * (x + 0.5) * (x + 0.5) + rx2 * (y - 1) * (y - 1) - rx2 * ry2;
    while(y >= 0)
    {
        plot4(xc, yc, x, y);
        y--;
        if(p > 0)
        {
            p = p + rx2 - 2 * rx2 * y;
        }
        else
        {
            x++;
            p = p + 2 * ry2 * x - 2 * rx2 * y + rx2;
        }
    }

    getch();
    closegraph();
}