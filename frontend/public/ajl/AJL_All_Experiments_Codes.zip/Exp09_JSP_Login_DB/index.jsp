<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Register</title>
</head>
<body>
<form action="servlet.jsp" method="post">
    Enter your UserName: <input type="text" name="name"><br><br>
    Enter your Password: <input type="password" name="pas"><br><br>
    Enter your email: <input type="email" name="email"><br><br>
    <input type="submit" value="Register">
</form>
</body>
</html>