import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

/* <applet code="DeptApplet.class" width="350" height="250"></applet> */

public class DeptApplet extends Applet implements ItemListener {
    List list;
    TextField tf;

    public void init() {
        list = new List(5);
        list.add("Computer Science");
        list.add("Electronics");
        list.add("Mechanical");
        list.add("Civil");
        list.add("Electrical");

        tf = new TextField(25);

        add(new Label("Select Department:"));
        add(list);
        add(new Label("You selected:"));
        add(tf);

        list.addItemListener(this);
    }

    public void itemStateChanged(ItemEvent e) {
        tf.setText(list.getSelectedItem());
    }
}