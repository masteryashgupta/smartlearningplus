import java.rmi.*;

public interface Calculator extends Remote {
    double calculate(double a, double b, char op) throws RemoteException;
}