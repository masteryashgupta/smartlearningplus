========================================================================
ADVANCE JAVA LAB (AJL) - EXPERIMENTS 1 TO 10
Smart Learning Plus - Complete Practical Code & Run Guide
========================================================================

Folder Structure:
- Exp01_AWT_Checkboxes/        : CourseCheckbox.java (AWT Checkbox & ItemListener)
- Exp02_Applet_Depts/          : DeptApplet.java, DeptPanel.java (Applet & AWT List)
- Exp03_Swing_Components/      : SwingComponents.java (JFrame, JButton, JRadioButton)
- Exp04_JDBC_CRUD/             : JDBCCRUD.java (MySQL Connector/J, PreparedStatement)
- Exp05_Socket_TCP/            : Server.java, Client.java (TCP Sockets, Port 6666)
- Exp06_RMI_Calculator/        : Calculator.java, CalculatorImpl.java, Server.java, Client.java
- Exp07_Servlet_HelloWorld/    : HelloServlet.java, web.xml (HttpServlet & Tomcat 9)
- Exp08_User_Registration/     : registration.html, register.jsp, RegisterServlet.java, web.xml
- Exp09_JSP_Login_DB/          : Index.html, Process.jsp, Welcome.jsp, index.jsp, servlet.jsp, login.jsp, wel.jsp
- Exp10_JSP_Grade_Calculator/  : marks.html, marks.jsp (JSP Scriptlets)
- HTML_Manuals/                : exp1.html to exp10.html, all.html, index.html

========================================================================
Quick Run Instructions:
1. Java GUI (Exp 1-3):
   javac <file>.java
   java <ClassName>

2. JDBC (Exp 4):
   Start MySQL service. Ensure mysql-connector-j-8.4.0.jar is in folder.
   javac -cp .;mysql-connector-j-8.4.0.jar JDBCCRUD.java
   java -cp .;mysql-connector-j-8.4.0.jar JDBCCRUD

3. TCP Socket (Exp 5):
   Terminal 1: java Server
   Terminal 2: java Client

4. RMI (Exp 6):
   javac *.java
   Terminal 1: start rmiregistry
   Terminal 2: java Server
   Terminal 3: java Client

5. Servlets & JSP (Exp 7-10):
   Copy app folders to %TOMCAT%\webapps\
   Startup Tomcat: %TOMCAT%\bin\startup.bat
   Access in browser at http://localhost:8080/<AppName>/
========================================================================
