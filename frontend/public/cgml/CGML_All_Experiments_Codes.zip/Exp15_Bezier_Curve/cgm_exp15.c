#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<graphics.h>

void main()
{
    int gd = DETECT, gm, err;
    int x[4], y[4], i, k;
    double t, u, a, b, c, d, bx, by;

    clrscr();
    printf("Enter the 4 control points (x y), one per line:\n");
    for(i = 0; i < 4; i++)
        scanf("%d%d", &x[i], &y[i]);

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    /* control polygon and control points */
    setcolor(DARKGRAY);
    for(i = 0; i < 3; i++)
        line(x[i], y[i], x[i + 1], y[i + 1]);
    setcolor(LIGHTGREEN);
    for(i = 0; i < 4; i++)
        circle(x[i], y[i], 4);

    /* the cubic Bezier curve */
    for(k = 0; k <= 1000; k++)
    {
        t = k / 1000.0;
        u = 1 - t;
        a = u * u * u;
        b = 3 * t * u * u;
        c = 3 * t * t * u;
        d = t * t * t;
        bx = a * x[0] + b * x[1] + c * x[2] + d * x[3];
        by = a * y[0] + b * y[1] + c * y[2] + d * y[3];
        putpixel((int)(bx + 0.5), (int)(by + 0.5), YELLOW);
    }

    outtextxy(10, 10, "Bezier curve (yellow), control points (green)");

    getch();
    closegraph();
}