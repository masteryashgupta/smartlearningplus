#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<graphics.h>

void bresenham(int x1, int y1, int x2, int y2)
{
    int dx, dy, sx, sy, x, y, p, i;

    dx = abs(x2 - x1);
    dy = abs(y2 - y1);
    sx = (x2 >= x1) ? 1 : -1;
    sy = (y2 >= y1) ? 1 : -1;
    x = x1;
    y = y1;
    putpixel(x, y, WHITE);

    if(dx >= dy)
    {
        p = 2 * dy - dx;
        for(i = 0; i < dx; i++)
        {
            x = x + sx;
            if(p < 0)
            {
                p = p + 2 * dy;
            }
            else
            {
                y = y + sy;
                p = p + 2 * (dy - dx);
            }
            putpixel(x, y, WHITE);
        }
    }
    else
    {
        p = 2 * dx - dy;
        for(i = 0; i < dy; i++)
        {
            y = y + sy;
            if(p < 0)
            {
                p = p + 2 * dx;
            }
            else
            {
                x = x + sx;
                p = p + 2 * (dx - dy);
            }
            putpixel(x, y, WHITE);
        }
    }
}

void main()
{
    int gd = DETECT, gm, err;
    int x1, y1, x2, y2;

    clrscr();
    printf("Enter first point (x1 y1): ");
    scanf("%d%d", &x1, &y1);
    printf("Enter second point (x2 y2): ");
    scanf("%d%d", &x2, &y2);

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    bresenham(x1, y1, x2, y2);

    getch();
    closegraph();
}