#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<math.h>
#include<graphics.h>

#define PI 3.14159265

/* box 100 wide, 60 high, 80 deep, centred at the origin */
float v[8][3] = {
    {-50, -30, -40}, {50, -30, -40}, {50, 30, -40}, {-50, 30, -40},
    {-50, -30,  40}, {50, -30,  40}, {50, 30,  40}, {-50, 30,  40}
};
int edge[12][2] = {
    {0, 1}, {1, 2}, {2, 3}, {3, 0},
    {4, 5}, {5, 6}, {6, 7}, {7, 4},
    {0, 4}, {1, 5}, {2, 6}, {3, 7}
};

/* oblique projection: x and y are shifted by 0.35 * z */
int px(float x, float z)
{
    return 320 + (int)floor(x - 0.35 * z + 0.5);
}

int py(float y, float z)
{
    return 240 - (int)floor(y - 0.35 * z + 0.5);
}

void drawbox(float p[8][3], int color)
{
    int i, a, b;
    setcolor(color);
    for(i = 0; i < 12; i++)
    {
        a = edge[i][0];
        b = edge[i][1];
        line(px(p[a][0], p[a][2]), py(p[a][1], p[a][2]),
             px(p[b][0], p[b][2]), py(p[b][1], p[b][2]));
    }
}

void main()
{
    int gd = DETECT, gm, err, ch, axis, i;
    float n[8][3];
    float tx, ty, tz, sx, sy, sz, angle, c, s, x, y, z;

    clrscr();
    printf("1. Translation\n2. Scaling\n3. Rotation\n");
    printf("Enter your choice: ");
    scanf("%d", &ch);

    for(i = 0; i < 8; i++)
    {
        n[i][0] = v[i][0];
        n[i][1] = v[i][1];
        n[i][2] = v[i][2];
    }

    if(ch == 1)
    {
        printf("Enter translation tx ty tz: ");
        scanf("%f%f%f", &tx, &ty, &tz);
        for(i = 0; i < 8; i++)
        {
            n[i][0] = v[i][0] + tx;
            n[i][1] = v[i][1] + ty;
            n[i][2] = v[i][2] + tz;
        }
    }
    else if(ch == 2)
    {
        printf("Enter scaling factors sx sy sz: ");
        scanf("%f%f%f", &sx, &sy, &sz);
        for(i = 0; i < 8; i++)
        {
            n[i][0] = v[i][0] * sx;
            n[i][1] = v[i][1] * sy;
            n[i][2] = v[i][2] * sz;
        }
    }
    else if(ch == 3)
    {
        printf("Rotate about 1. x-axis  2. y-axis  3. z-axis: ");
        scanf("%d", &axis);
        printf("Enter angle in degrees: ");
        scanf("%f", &angle);
        c = cos(angle * PI / 180);
        s = sin(angle * PI / 180);
        for(i = 0; i < 8; i++)
        {
            x = v[i][0]; y = v[i][1]; z = v[i][2];
            if(axis == 1)
            {
                n[i][0] = x;
                n[i][1] = y * c - z * s;
                n[i][2] = y * s + z * c;
            }
            else if(axis == 2)
            {
                n[i][0] = x * c + z * s;
                n[i][1] = y;
                n[i][2] = -x * s + z * c;
            }
            else
            {
                n[i][0] = x * c - y * s;
                n[i][1] = x * s + y * c;
                n[i][2] = z;
            }
        }
    }
    else
    {
        printf("Wrong choice");
        getch();
        exit(0);
    }

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    drawbox(v, WHITE);
    drawbox(n, YELLOW);
    outtextxy(10, 10, "White = original, Yellow = transformed");

    getch();
    closegraph();
}