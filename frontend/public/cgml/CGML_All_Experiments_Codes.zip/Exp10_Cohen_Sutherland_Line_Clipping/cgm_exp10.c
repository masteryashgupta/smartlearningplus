#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<graphics.h>

#define RC_TOP 8
#define RC_BOTTOM 4
#define RC_RIGHT 2
#define RC_LEFT 1

int xmin, ymin, xmax, ymax;

int code(float x, float y)
{
    int c = 0;
    if(y < ymin) c = c | RC_TOP;
    if(y > ymax) c = c | RC_BOTTOM;
    if(x > xmax) c = c | RC_RIGHT;
    if(x < xmin) c = c | RC_LEFT;
    return c;
}

void main()
{
    int gd = DETECT, gm, err;
    int ox1, oy1, ox2, oy2, c1, c2, outc, accept = 0;
    float x1, y1, x2, y2, x, y;

    clrscr();
    printf("Enter window corners xmin ymin xmax ymax: ");
    scanf("%d%d%d%d", &xmin, &ymin, &xmax, &ymax);
    printf("Enter line end points x1 y1 x2 y2: ");
    scanf("%d%d%d%d", &ox1, &oy1, &ox2, &oy2);

    x1 = ox1; y1 = oy1;
    x2 = ox2; y2 = oy2;
    c1 = code(x1, y1);
    c2 = code(x2, y2);

    while(1)
    {
        if((c1 | c2) == 0)
        {
            accept = 1;
            break;
        }
        if((c1 & c2) != 0)
            break;

        if(c1 != 0)
            outc = c1;
        else
            outc = c2;

        if(outc & RC_TOP)
        {
            x = x1 + (x2 - x1) * (ymin - y1) / (y2 - y1);
            y = ymin;
        }
        else if(outc & RC_BOTTOM)
        {
            x = x1 + (x2 - x1) * (ymax - y1) / (y2 - y1);
            y = ymax;
        }
        else if(outc & RC_RIGHT)
        {
            y = y1 + (y2 - y1) * (xmax - x1) / (x2 - x1);
            x = xmax;
        }
        else
        {
            y = y1 + (y2 - y1) * (xmin - x1) / (x2 - x1);
            x = xmin;
        }

        if(outc == c1)
        {
            x1 = x; y1 = y;
            c1 = code(x1, y1);
        }
        else
        {
            x2 = x; y2 = y;
            c2 = code(x2, y2);
        }
    }

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    /* before clipping */
    setcolor(WHITE);
    rectangle(xmin, ymin, xmax, ymax);
    setcolor(RED);
    line(ox1, oy1, ox2, oy2);
    outtextxy(10, 10, "Before clipping (press a key)");
    getch();

    /* after clipping */
    cleardevice();
    setcolor(WHITE);
    rectangle(xmin, ymin, xmax, ymax);
    if(accept)
    {
        setcolor(GREEN);
        line((int)(x1 + 0.5), (int)(y1 + 0.5), (int)(x2 + 0.5), (int)(y2 + 0.5));
    }
    outtextxy(10, 10, "After clipping (press a key)");
    getch();
    closegraph();
}