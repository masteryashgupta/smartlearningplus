%{
#include<stdio.h>
#include<stdlib.h>
int yylex();
int yyerror(char *s);
%}

%token NUMBER
%left '+' '-'
%left '*' '/'
%right UMINUS

%%
S : E    { printf("Result = %d\n", $1); }
  ;

E : E '+' E             { $$ = $1 + $3; }
  | E '-' E             { $$ = $1 - $3; }
  | E '*' E             { $$ = $1 * $3; }
  | E '/' E             {
                            if($3 == 0)
                            {
                                printf("Division by zero\n");
                                exit(1);
                            }
                            $$ = $1 / $3;
                        }
  | '-' E %prec UMINUS  { $$ = -$2; }
  | '(' E ')'           { $$ = $2; }
  | NUMBER              { $$ = $1; }
  ;
%%

int yyerror(char *s)
{
    printf("Expression is invalid\n");
    return 0;
}

int main()
{
    printf("Enter the expression\n");
    yyparse();
    return 0;
}