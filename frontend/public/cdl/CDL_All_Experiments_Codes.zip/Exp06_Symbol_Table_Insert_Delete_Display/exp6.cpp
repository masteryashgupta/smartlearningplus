#include<stdio.h>
#include<conio.h>
#include<string.h>

struct SymbTab
{
    char label[10];
    char symbol[10];
    int addr;
};

struct SymbTab table[20];
int size = 0;

int Search(char lab[])
{
    int i;
    for(i = 0; i < size; i++)
    {
        if(strcmp(table[i].label, lab) == 0)
            return i;
    }
    return -1;
}

void Insert()
{
    char l[10];
    printf("\nEnter the label: ");
    scanf("%s", l);

    if(Search(l) != -1)
    {
        printf("Label already exists, duplicate can't be inserted\n");
        return;
    }
    if(size == 20)
    {
        printf("Table is full\n");
        return;
    }

    strcpy(table[size].label, l);
    printf("Enter the symbol: ");
    scanf("%s", table[size].symbol);
    printf("Enter the address: ");
    scanf("%d", &table[size].addr);
    size++;
    printf("Label inserted\n");
}

void Display()
{
    int i;
    printf("\nLABEL\tSYMBOL\tADDRESS\n");
    for(i = 0; i < size; i++)
    {
        printf("%s\t%s\t%d\n", table[i].label, table[i].symbol, table[i].addr);
    }
}

void Delete()
{
    char l[10];
    int pos, i;
    printf("\nEnter the label to be deleted: ");
    scanf("%s", l);

    pos = Search(l);
    if(pos == -1)
    {
        printf("Label not found\n");
        return;
    }

    for(i = pos; i < size - 1; i++)
        table[i] = table[i + 1];
    size--;

    printf("After deletion:\n");
    Display();
}

void main()
{
    int op;
    char la[10];

    clrscr();
    do
    {
        printf("\n\tSYMBOL TABLE IMPLEMENTATION\n");
        printf("\n\t1.INSERT\n\t2.DISPLAY\n\t3.DELETE\n\t4.SEARCH\n\t5.END\n");
        printf("\n\tEnter your option: ");
        scanf("%d", &op);

        switch(op)
        {
            case 1: Insert(); break;
            case 2: Display(); break;
            case 3: Delete(); break;
            case 4:
                printf("\nEnter the label to be searched: ");
                scanf("%s", la);
                if(Search(la) != -1)
                    printf("The label is present in the symbol table\n");
                else
                    printf("The label is not present in the symbol table\n");
                break;
            case 5: break;
            default: printf("Wrong choice\n");
        }
    } while(op != 5);

    getch();
}