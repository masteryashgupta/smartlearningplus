#include<stdio.h>
#include<conio.h>
#include<ctype.h>
#include<string.h>

char prod[20][10];
int first[26][128], follow[26][128];
char nt[26];
int n, nn = 0, changed;

void add(int s[][128], char A, int ch)
{
    if(!s[A - 'A'][ch])
    {
        s[A - 'A'][ch] = 1;
        changed = 1;
    }
}

void addset(int s[][128], char A, int t[][128], char B, int noeps)
{
    int ch;
    for(ch = 0; ch < 128; ch++)
        if(t[B - 'A'][ch] && !(noeps && ch == '#'))
            add(s, A, ch);
}

void findfirst()
{
    int p, k, alleps;
    char A, X;
    do
    {
        changed = 0;
        for(p = 0; p < n; p++)
        {
            A = prod[p][0];
            alleps = 1;
            for(k = 2; prod[p][k] != '\0'; k++)
            {
                X = prod[p][k];
                if(!isupper(X))
                {
                    add(first, A, X);
                    alleps = 0;
                    break;
                }
                addset(first, A, first, X, 1);
                if(!first[X - 'A']['#'])
                {
                    alleps = 0;
                    break;
                }
            }
            if(alleps)
                add(first, A, '#');
        }
    } while(changed);
}

void findfollow()
{
    int p, k, j, nullable;
    char B, Y;
    add(follow, prod[0][0], '$');
    do
    {
        changed = 0;
        for(p = 0; p < n; p++)
            for(k = 2; prod[p][k] != '\0'; k++)
            {
                B = prod[p][k];
                if(!isupper(B))
                    continue;
                nullable = 1;
                for(j = k + 1; prod[p][j] != '\0'; j++)
                {
                    Y = prod[p][j];
                    if(!isupper(Y))
                    {
                        add(follow, B, Y);
                        nullable = 0;
                        break;
                    }
                    addset(follow, B, first, Y, 1);
                    if(!first[Y - 'A']['#'])
                    {
                        nullable = 0;
                        break;
                    }
                }
                if(nullable)
                    addset(follow, B, follow, prod[p][0], 0);
            }
    } while(changed);
}

void show(char *name, int s[][128], char A)
{
    int ch, comma = 0;
    printf("%s(%c) = { ", name, A);
    for(ch = 0; ch < 128; ch++)
        if(s[A - 'A'][ch])
        {
            if(comma)
                printf(", ");
            printf("%c", ch);
            comma = 1;
        }
    printf(" }\n");
}

void main()
{
    int i, j, found;

    clrscr();
    printf("Enter number of productions: ");
    scanf("%d", &n);
    printf("Enter productions like E=TR (use # for epsilon).\n");
    printf("The first production must have the start symbol.\n");
    for(i = 0; i < n; i++)
    {
        scanf("%s", prod[i]);
        found = 0;
        for(j = 0; j < nn; j++)
            if(nt[j] == prod[i][0])
                found = 1;
        if(!found)
            nt[nn++] = prod[i][0];
    }

    findfirst();
    findfollow();

    printf("\n");
    for(i = 0; i < nn; i++)
        show("First", first, nt[i]);
    printf("\n");
    for(i = 0; i < nn; i++)
        show("Follow", follow, nt[i]);
    getch();
}