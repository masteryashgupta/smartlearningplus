%{
#include<stdio.h>
#include<stdlib.h>
int yylex();
int yyerror(char *msg);
%}

%token A B C D NL

%%
stmt : X Y NL    { printf("valid string\n"); exit(0); }
     ;

X    : A X B
     | A B
     ;

Y    : C Y D
     | C D
     ;
%%

int yyerror(char *msg)
{
    printf("invalid string\n");
    exit(0);
}

int main()
{
    printf("enter the string\n");
    yyparse();
    return 0;
}