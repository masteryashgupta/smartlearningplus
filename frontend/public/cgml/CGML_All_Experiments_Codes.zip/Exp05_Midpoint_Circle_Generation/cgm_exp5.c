#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<graphics.h>

void plot8(int a, int b, int x, int y)
{
    putpixel(a + x, b + y, RED);
    putpixel(a - x, b + y, RED);
    putpixel(a + x, b - y, RED);
    putpixel(a - x, b - y, RED);
    putpixel(a + y, b + x, RED);
    putpixel(a - y, b + x, RED);
    putpixel(a + y, b - x, RED);
    putpixel(a - y, b - x, RED);
}

void main()
{
    int gd = DETECT, gm, err;
    int a, b, r, x, y, p;

    clrscr();
    printf("Enter centre (a b): ");
    scanf("%d%d", &a, &b);
    printf("Enter radius r: ");
    scanf("%d", &r);

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    x = 0;
    y = r;
    p = 1 - r;

    while(x <= y)
    {
        plot8(a, b, x, y);
        if(p < 0)
        {
            p = p + 2 * x + 3;
        }
        else
        {
            p = p + 2 * (x - y) + 5;
            y--;
        }
        x++;
    }

    getch();
    closegraph();
}