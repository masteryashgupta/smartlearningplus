<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
out.println("Welcome to world of jsp");
%>