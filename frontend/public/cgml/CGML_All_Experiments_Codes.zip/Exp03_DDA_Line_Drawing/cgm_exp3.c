#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<math.h>
#include<graphics.h>

void main()
{
    int gd = DETECT, gm, err;
    int x1, y1, x2, y2, dx, dy, steps, k;
    float x, y, xinc, yinc;

    clrscr();
    printf("Enter first point (x1 y1): ");
    scanf("%d%d", &x1, &y1);
    printf("Enter second point (x2 y2): ");
    scanf("%d%d", &x2, &y2);

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    dx = x2 - x1;
    dy = y2 - y1;

    if(abs(dx) > abs(dy))
        steps = abs(dx);
    else
        steps = abs(dy);

    if(steps == 0)
        steps = 1;

    xinc = (float)dx / steps;
    yinc = (float)dy / steps;

    x = x1;
    y = y1;

    for(k = 0; k <= steps; k++)
    {
        putpixel((int)(x + 0.5), (int)(y + 0.5), WHITE);
        x = x + xinc;
        y = y + yinc;
    }

    getch();
    closegraph();
}