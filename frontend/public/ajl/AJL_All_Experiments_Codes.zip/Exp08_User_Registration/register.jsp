<html>
<head><title>Registration Details</title></head>
<body>
<p>
<%
String fname = request.getParameter("fname");
String lname = request.getParameter("lname");
String uname = request.getParameter("uname");
String email = request.getParameter("email");
String pwd = request.getParameter("pwd");
String cpwd = request.getParameter("cpwd");
String add = request.getParameter("add");

out.print("First name is : " + fname + "<br>");
out.print("Last name is : " + lname + "<br>");
out.print("User name is : " + uname + "<br>");
out.print("Email is : " + email + "<br>");
out.print("Password is : " + pwd + "<br>");
out.print("Confirm Password is : " + cpwd + "<br>");
out.print("Address is : " + add + "<br>");
%>
</p>
</body>
</html>