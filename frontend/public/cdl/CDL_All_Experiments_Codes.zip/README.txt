CDL – Compiler Design Lab
All Experiments Code Files
==========================

Folder structure:
  Exp01_Introduction_to_Compiler_Design/
    exp1.txt          – theory write-up
  Exp02_Identify_Keyword/
    exp2.cpp          – C++ program
  ...
  Exp07_LEX_Validate.../
    exp7_mobile.l     – LEX for mobile validation
    exp7_email.l      – LEX for email
    ...

For LEX/YACC programs (Exp 7-12):
  sudo apt install flex bison gcc
  lex file.l && cc lex.yy.c -lfl && ./a.out
  (For YACC: yacc -d file.y && lex file.l && cc y.tab.c lex.yy.c && ./a.out)

For C++ programs (Exp 2-6, 13):
  g++ file.cpp -o out && ./out

HTML_Manuals/ folder contains the full practical file pages.
