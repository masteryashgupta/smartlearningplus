import java.awt.*;
import java.awt.event.*;

public class CourseCheckbox extends Frame implements ItemListener {
    Checkbox c1, c2, c3, c4;
    Label l1;

    CourseCheckbox() {
        setTitle("Course Selection");
        setLayout(new FlowLayout());

        c1 = new Checkbox("B.Tech");
        c2 = new Checkbox("BCA");
        c3 = new Checkbox("MCA");
        c4 = new Checkbox("MBA");
        l1 = new Label("Selected: None                              ");

        add(c1);
        add(c2);
        add(c3);
        add(c4);
        add(l1);

        c1.addItemListener(this);
        c2.addItemListener(this);
        c3.addItemListener(this);
        c4.addItemListener(this);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setSize(350, 200);
        setVisible(true);
    }

    public void itemStateChanged(ItemEvent e) {
        String courses = "";
        if (c1.getState()) courses += "B.Tech ";
        if (c2.getState()) courses += "BCA ";
        if (c3.getState()) courses += "MCA ";
        if (c4.getState()) courses += "MBA ";

        if (courses.equals("")) courses = "None";
        l1.setText("Selected: " + courses);
    }

    public static void main(String[] args) {
        new CourseCheckbox();
    }
}