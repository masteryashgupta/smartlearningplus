<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
String name = request.getParameter("name");
String pass = request.getParameter("pas");
String email = request.getParameter("email");

Class.forName("com.mysql.cj.jdbc.Driver");
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/labdb", "root", "root123");
PreparedStatement ps = con.prepareStatement("insert into reg values(?,?,?)");
ps.setString(1, name);
ps.setString(2, pass);
ps.setString(3, email);
int i = ps.executeUpdate();
if (i > 0) {
    response.sendRedirect("login.jsp");
} else {
    out.println("Try Again");
}
%>