#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<math.h>
#include<graphics.h>

#define PI 3.14159265

int sx(float x)
{
    return 320 + (int)floor(x + 0.5);
}

int sy(float y)
{
    return 240 - (int)floor(y + 0.5);
}

void drawtri(float x[], float y[], int color)
{
    int i, j;
    setcolor(color);
    for(i = 0; i < 3; i++)
    {
        j = (i + 1) % 3;
        line(sx(x[i]), sy(y[i]), sx(x[j]), sy(y[j]));
    }
}

void main()
{
    int gd = DETECT, gm, err, ch, r, i;
    float x[3], y[3], nx[3], ny[3];
    float tx, ty, scx, scy, shx, shy, px, py, angle, c, s;

    clrscr();
    printf("Enter the 3 vertices of the triangle (x y), one per line:\n");
    for(i = 0; i < 3; i++)
        scanf("%f%f", &x[i], &y[i]);

    printf("\n1. Translation\n2. Scaling\n3. Rotation\n4. Shearing\n5. Reflection\n");
    printf("Enter your choice: ");
    scanf("%d", &ch);

    switch(ch)
    {
        case 1:
            printf("Enter translation tx ty: ");
            scanf("%f%f", &tx, &ty);
            for(i = 0; i < 3; i++)
            {
                nx[i] = x[i] + tx;
                ny[i] = y[i] + ty;
            }
            break;
        case 2:
            printf("Enter scaling factors sx sy: ");
            scanf("%f%f", &scx, &scy);
            for(i = 0; i < 3; i++)
            {
                nx[i] = x[i] * scx;
                ny[i] = y[i] * scy;
            }
            break;
        case 3:
            printf("Enter angle in degrees (anticlockwise): ");
            scanf("%f", &angle);
            printf("Enter pivot point px py (0 0 for origin): ");
            scanf("%f%f", &px, &py);
            c = cos(angle * PI / 180);
            s = sin(angle * PI / 180);
            for(i = 0; i < 3; i++)
            {
                nx[i] = px + (x[i] - px) * c - (y[i] - py) * s;
                ny[i] = py + (x[i] - px) * s + (y[i] - py) * c;
            }
            break;
        case 4:
            printf("Enter shear factors shx shy (use 0 to skip one): ");
            scanf("%f%f", &shx, &shy);
            for(i = 0; i < 3; i++)
            {
                nx[i] = x[i] + shx * y[i];
                ny[i] = y[i] + shy * x[i];
            }
            break;
        case 5:
            printf("1. About x-axis\n2. About y-axis\n3. About origin\n4. About line y = x\n");
            printf("Enter your choice: ");
            scanf("%d", &r);
            for(i = 0; i < 3; i++)
            {
                if(r == 1) { nx[i] = x[i];  ny[i] = -y[i]; }
                else if(r == 2) { nx[i] = -x[i]; ny[i] = y[i]; }
                else if(r == 3) { nx[i] = -x[i]; ny[i] = -y[i]; }
                else { nx[i] = y[i]; ny[i] = x[i]; }
            }
            break;
        default:
            printf("Wrong choice");
            getch();
            exit(0);
    }

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    /* axes: the origin (0,0) is at the centre of the screen */
    setcolor(DARKGRAY);
    line(0, 240, 639, 240);
    line(320, 0, 320, 479);

    drawtri(x, y, WHITE);
    drawtri(nx, ny, YELLOW);
    outtextxy(10, 10, "White = original, Yellow = transformed");

    getch();
    closegraph();
}