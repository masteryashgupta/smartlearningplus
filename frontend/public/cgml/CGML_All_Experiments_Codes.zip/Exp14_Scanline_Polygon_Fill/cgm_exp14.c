#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<graphics.h>

void main()
{
    int gd = DETECT, gm, err;
    int n, i, j, k, y, ymin, ymax, cnt, x1, y1, x2, y2, col, tmp;
    int px[10], py[10];
    float xi[10], t;

    clrscr();
    printf("Enter number of vertices (3 to 10): ");
    scanf("%d", &n);
    if(n < 3 || n > 10)
    {
        printf("Number of vertices must be 3 to 10");
        getch();
        exit(0);
    }
    printf("Enter the vertices (x y), one per line, in order:\n");
    for(i = 0; i < n; i++)
        scanf("%d%d", &px[i], &py[i]);
    printf("Enter fill colour (1 to 14): ");
    scanf("%d", &col);

    ymin = py[0];
    ymax = py[0];
    for(i = 1; i < n; i++)
    {
        if(py[i] < ymin) ymin = py[i];
        if(py[i] > ymax) ymax = py[i];
    }

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    setcolor(col);
    for(y = ymin; y <= ymax; y++)
    {
        cnt = 0;
        for(i = 0; i < n; i++)
        {
            j = (i + 1) % n;
            x1 = px[i]; y1 = py[i];
            x2 = px[j]; y2 = py[j];
            if(y1 == y2)
                continue;
            if(y1 > y2)
            {
                tmp = x1; x1 = x2; x2 = tmp;
                tmp = y1; y1 = y2; y2 = tmp;
            }
            if(y >= y1 && y < y2)
            {
                xi[cnt] = x1 + (float)(y - y1) * (x2 - x1) / (y2 - y1);
                cnt++;
            }
        }

        for(i = 0; i < cnt - 1; i++)
            for(k = 0; k < cnt - 1 - i; k++)
                if(xi[k] > xi[k + 1])
                {
                    t = xi[k];
                    xi[k] = xi[k + 1];
                    xi[k + 1] = t;
                }

        for(k = 0; k + 1 < cnt; k += 2)
            line((int)(xi[k] + 0.5), y, (int)(xi[k + 1] + 0.5), y);
    }

    setcolor(WHITE);
    for(i = 0; i < n; i++)
    {
        j = (i + 1) % n;
        line(px[i], py[i], px[j], py[j]);
    }

    getch();
    closegraph();
}