#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<graphics.h>

extern unsigned _stklen = 40000U;

void floodfill4(int x, int y, int newcol, int oldcol)
{
    if(getpixel(x, y) == oldcol)
    {
        putpixel(x, y, newcol);
        floodfill4(x + 1, y, newcol, oldcol);
        floodfill4(x - 1, y, newcol, oldcol);
        floodfill4(x, y + 1, newcol, oldcol);
        floodfill4(x, y - 1, newcol, oldcol);
    }
}

void main()
{
    int gd = DETECT, gm, err;
    int col, oldcol;

    clrscr();
    printf("Enter fill colour (1 to 14): ");
    scanf("%d", &col);
    if(col < 1 || col > 14)
    {
        printf("Colour must be between 1 and 14");
        getch();
        exit(0);
    }

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    setcolor(WHITE);
    rectangle(100, 100, 160, 140);

    oldcol = getpixel(130, 120);
    floodfill4(130, 120, col, oldcol);

    getch();
    closegraph();
}