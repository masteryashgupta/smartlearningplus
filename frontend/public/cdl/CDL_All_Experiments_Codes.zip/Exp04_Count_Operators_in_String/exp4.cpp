#include<stdio.h>
#include<conio.h>

void main()
{
    int count = 0, i;
    char string[100];

    clrscr();
    printf("Enter your string :");
    gets(string);

    for(i = 0; string[i] != '\0'; i++)
    {
        if(string[i]=='+' || string[i]=='-' || string[i]=='*' || string[i]=='/')
        {
            count++;
        }
    }

    printf("Total Number of operators is : %d ", count);
    getch();
}