#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<math.h>
#include<dos.h>
#include<graphics.h>

void fish(int x, int y, int color)
{
    setcolor(color);
    ellipse(x, y, 0, 360, 35, 18);              /* body */
    line(x + 33, y - 5, x + 55, y - 18);        /* tail */
    line(x + 55, y - 18, x + 55, y + 18);
    line(x + 55, y + 18, x + 33, y + 5);
    line(x - 5, y - 17, x + 5, y - 30);         /* top fin */
    line(x + 5, y - 30, x + 15, y - 16);
    arc(x - 12, y, 100, 260, 12);               /* gill */
    circle(x - 20, y - 5, 3);                   /* eye */
}

void main()
{
    int gd = DETECT, gm, err;
    int x, y;

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if(err != grOk)
    {
        printf("Graphics error: %s", grapherrormsg(err));
        getch();
        exit(1);
    }

    for(x = 560; x > 60 && !kbhit(); x -= 4)
    {
        y = 240 + (int)(30 * sin(x / 30.0));
        fish(x, y, LIGHTCYAN);
        delay(40);
        fish(x, y, BLACK);
    }

    y = 240 + (int)(30 * sin(x / 30.0));
    fish(x, y, LIGHTCYAN);

    getch();
    closegraph();
}