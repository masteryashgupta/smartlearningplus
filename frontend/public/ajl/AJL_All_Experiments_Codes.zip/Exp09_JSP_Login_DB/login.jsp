<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Login</title>
</head>
<body>
<form action="wel.jsp" method="post">
    Name: <input type="text" name="name"><br><br>
    Password: <input type="password" name="pas"><br><br>
    <input type="submit" value="Login">
</form>
</body>
</html>