<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Welcome</title>
</head>
<body>
<%
String name = request.getParameter("name");
String pass = request.getParameter("pas");

Class.forName("com.mysql.cj.jdbc.Driver");
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/labdb", "root", "root123");
PreparedStatement ps = con.prepareStatement("select * from reg where name=? and pwd=?");
ps.setString(1, name);
ps.setString(2, pass);
ResultSet rs = ps.executeQuery();
if (rs.next()) {
    out.println("<h1>Welcome : " + name + "</h1>");
} else {
    out.println("<h1>Not Done</h1>");
}
%>
</body>
</html>