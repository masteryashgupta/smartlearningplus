import javax.swing.*;
import java.awt.event.*;

public class SwingComponents extends JFrame implements ActionListener, ItemListener {
    JTextField tf;
    JButton btn;
    JToggleButton toggle;
    JCheckBox cb1, cb2, cb3;
    JRadioButton rb1, rb2, rb3;
    ButtonGroup bg;

    public SwingComponents() {
        setTitle("Swing Components Example");
        setSize(500, 450);
        setLayout(null);

        JLabel l1 = new JLabel("Enter Your Name:");
        l1.setBounds(30, 20, 120, 25);
        add(l1);
        tf = new JTextField();
        tf.setBounds(160, 20, 200, 25);
        add(tf);

        btn = new JButton("Submit");
        btn.setBounds(160, 60, 100, 30);
        btn.addActionListener(this);
        add(btn);

        toggle = new JToggleButton("OFF");
        toggle.setBounds(280, 60, 80, 30);
        toggle.addItemListener(this);
        add(toggle);

        JLabel l2 = new JLabel("Languages:");
        l2.setBounds(30, 120, 100, 25);
        add(l2);
        cb1 = new JCheckBox("C");
        cb1.setBounds(160, 120, 80, 25);
        cb2 = new JCheckBox("Java");
        cb2.setBounds(160, 150, 80, 25);
        cb3 = new JCheckBox("Python");
        cb3.setBounds(160, 180, 100, 25);
        add(cb1);
        add(cb2);
        add(cb3);

        JLabel l3 = new JLabel("Gender:");
        l3.setBounds(30, 240, 100, 25);
        add(l3);
        rb1 = new JRadioButton("Male");
        rb1.setBounds(160, 240, 80, 25);
        rb2 = new JRadioButton("Female");
        rb2.setBounds(160, 270, 100, 25);
        rb3 = new JRadioButton("Other");
        rb3.setBounds(160, 300, 100, 25);
        bg = new ButtonGroup();
        bg.add(rb1);
        bg.add(rb2);
        bg.add(rb3);
        add(rb1);
        add(rb2);
        add(rb3);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(this, "Welcome " + tf.getText());
    }

    public void itemStateChanged(ItemEvent e) {
        if (toggle.isSelected())
            toggle.setText("ON");
        else
            toggle.setText("OFF");
    }

    public static void main(String[] args) {
        new SwingComponents();
    }
}